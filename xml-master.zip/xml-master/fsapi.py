# -*- coding: UTF-8 -*-

import re
import base64
import requests

from six import ensure_text
from oathscrapers.modules import source_utils
from oathscrapers.modules import log_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['fsapi.xyz']
        self.base_link = 'https://fsapi.xyz'
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0', 'Referer': self.base_link}


#Auto Embed Movies by IMDB ID
#URL: https://fsapi.xyz/movie/{IMDB_ID}
#Example: https://fsapi.xyz/movie/tt7286456
#view-source:https://fsapi.xyz/movie/tt7286456
#"https://fsapi.xyz/play?&url=aHR0cHM6Ly9hcGkuMTIzbW92aWUuY2MvaW1kYi5waHA/aW1kYj10dDcyODY0NTYmc2VydmVyPXZjdQ=="


#Auto Embed Tv Series by IMDB ID
#URL: https://fsapi.xyz/tv-imdb/{IMDB_ID}-{SEASON_NUMBER}-{EPISODE_NUMBER}
#Example: https://fsapi.xyz/tv-imdb/tt6128300-1-1
#view-source:https://fsapi.xyz/tv-imdb/tt6128300-1-1
#"https://fsapi.xyz/play?url=aHR0cHM6Ly93d3cuMmVtYmVkLnJ1L2VtYmVkL2ltZGIvdHY/aWQ9dHQ2MTI4MzAwJnM9MSZlPTE="


#Auto Embed Anime Episodes by IMDB ID
#URL: https://fsapi.xyz/imdb-anime/{IMDB_ID}-{SEASON_NUMBER}-{EPISODE_NUMBER}
#Example: https://fsapi.xyz/imdb-anime/tt12117218-1-6
#view-source:https://fsapi.xyz/imdb-anime/tt12117218-1-6
#"https://fsapi.xyz/play?url=Ly92aWRzdHJlYW1pbmcuaW8vc3RyZWFtaW5nLnBocD9pZD1NVFF6T1RVNA=="


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.base_link + '/movie/%s' % imdb
            return url
        except:
            log_utils.log('fsapi exception', 1)
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = imdb
            return url
        except:
            log_utils.log('fsapi exception', 1)
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url == None:
                return
            tvshow = url
            anime = source_utils.is_anime('show', 'tvdb', tvdb)
            if anime:
                url = self.base_link + '/imdb-anime/%s-%s-%s' % (tvshow, season, episode)
            else:
                url = self.base_link + '/tv-imdb/%s-%s-%s' % (tvshow, season, episode)
            return url
        except:
            log_utils.log('fsapi exception', 1)
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None:
                return sources
            r = requests.get(url, headers=self.headers).content
            r = ensure_text(r, errors='ignore')
            match = re.findall('''&url=(.+?)" rel=''', r)
            for url in match:
                url = base64.b64decode(url)
                url = ensure_text(url, errors='ignore')
                url = "https:" + url if not url.startswith('http') else url
                # Ends here likey without errors but due to the sources being shit the results dont show.
                # Most likely needs scraped again deeper per result and further results pulled for use from each link.
                #log_utils.log('fsapi links : %s' % url)
                quality, info = source_utils.get_release_quality(url, url)
                valid, host = source_utils.is_host_valid(url, hostDict)
                if valid:
                    sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': False})
            return sources
        except:
            log_utils.log('fsapi exception', 1)
            return sources


    def resolve(self, url):
        return url


