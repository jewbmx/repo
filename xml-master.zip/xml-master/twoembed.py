# -*- coding: utf-8 -*-
"""
    **Created by Tempest**
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""

import re
import requests

from six import ensure_text
from oathscrapers import parse_qs, urljoin, urlencode
from oathscrapers.modules import client
from oathscrapers.modules import source_utils
from oathscrapers.modules import log_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['2embed.ru']
        self.base_link = 'https://www.2embed.ru'
        self.search_link = '/embed/imdb/movie?id=%s'
        self.search_link2 = '/embed/tmdb/tv?id=%s&s=%s&e=%s'
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0', 'Referer': self.base_link}


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            log_utils.log('twoembed exception', 1)
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            log_utils.log('twoembed exception', 1)
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            log_utils.log('twoembed exception', 1)
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            items = []
            if url is None:
                return sources
            hostDict = hostprDict + hostDict
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            if 'tvdb' in data:
                urls = self.search_link2 % (data['tvdb'], data['season'], data['episode'])
            else:
                urls = self.search_link % data['imdb']
            try:
                url = urljoin(self.base_link, urls)
                posts = requests.get(url, headers=self.headers).content
                posts = ensure_text(posts, errors='ignore')
                r = re.compile('data-id="(.+?)">.+?</a>').findall(posts)
                r = [i for i in r]
                items += r
            except:
                return
            for item in items:
                try:
                    item = 'https://www.2embed.ru/ajax/embed/play?id=%s&_token=' % item
                    # Breaks here returning a error.
                    # twoembed : b'{"status":false,"msg":"Bad request."}'
                    url = requests.get(item, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0', 'Referer': urls}).content
                    url = ensure_text(url, errors='ignore')
                    url = re.findall('"link":"(.+?)","sources"', url)
                    for url in url:
                        valid, host = source_utils.is_host_valid(url, hostDict)
                        sources.append({'source': host, 'quality': 'SD', 'language': 'en', 'url': url, 'direct': False, 'debridonly': False})
                except:
                    pass
            return sources
        except:
            log_utils.log('twoembed exception', 1)
            return sources


    def resolve(self, url):
        return url


