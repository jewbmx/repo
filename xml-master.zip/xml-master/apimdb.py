# -*- coding: utf-8 -*-

import re
import requests

from six import ensure_text
from oathscrapers import parse_qs, urljoin, urlencode, quote_plus

from oathscrapers.modules import client
from oathscrapers.modules import source_utils
from oathscrapers.modules import log_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['apimdb.net']
        self.base_link = 'https://apimdb.net'
        self.search_link = '/e/movie/%s'
        self.search_link2 = '/e/tv/%s/%s/%s'
        self.headers = {'User-Agent': client.agent(), 'Referer': self.base_link}


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.base_link + self.search_link % imdb
            return url
        except:
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = imdb
            return url
        except:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return
            url = self.base_link + self.search_link2 % (imdb, season, episode)
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        hostDict = hostprDict + hostDict
        sources = []
        try:
            if url is None:
                return sources
            page = requests.get(url, headers=self.headers).content
            page = ensure_text(page, errors='replace')
            urls = re.findall('<div class="server" data-src="(.+?)">', page)
            for url in urls:
                try:
                    url = self.base_link + url
                    r = requests.get(url, headers=self.headers).content
                    r = ensure_text(r, errors='replace')
                    url = client.parseDOM(r, 'iframe', ret='src')[0]
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if valid:
                        sources.append({'source': host, 'quality': 'HD', 'language': 'en', 'info': '', 'url': url, 'direct': False, 'debridonly': False})
                    else:
                        if any(v in host for v in ['voxzer.org']):
                            continue
                        log_utils.log('apimdb Source Testing : ' + repr(host) + '  -  ' + repr(url))
                        url = self.rescrape(url)
                        sources.append({'source': host, 'quality': 'HD', 'language': 'en', 'info': 'direct', 'url': url, 'direct': True, 'debridonly': False})
                except:
                    pass
            return sources
        except:
            log_utils.log('apimdb Exception', 1)
            return sources


# 'voxzer.org'  -  'https://player.voxzer.org/view/4e05572f915e4c0d27cac60c'
# uses jwplayer crap
# 'vidembed.net'  -  'https://vidembed.net/load.php?id=MzQ0NjY4&amp;title=Fatherhood++Episode+0&amp;typesub=SUB&amp;sub=L2ZhdGhlcmhvb2QvZmF0aGVyaG9vZC52dHQ=&amp;cover=Y292ZXIvZmF0aGVyaG9vZC5wbmc='
# scrapes proper url with rescrape def.


    def rescrape(self, url):
        if any(v in url for v in ['vidembed.net']):
            try:
                r = requests.get(url, headers=self.headers).text
                r = ensure_text(r, errors='replace')
                link = re.findall(r'(?:file|source)(?:\:)\s*(?:\"|\')(.+?)(?:\"|\')', r)[0]
                log_utils.log('apimdb rescrape link : ' + repr(link))
                return link
            except:
                pass
        log_utils.log('apimdb rescrape url : ' + repr(url))
        return url


    def resolve(self, url):
        if 'google' in url:
            from oathscrapers.modules import directstream
            url = directstream.googlepass(url)
        return url






