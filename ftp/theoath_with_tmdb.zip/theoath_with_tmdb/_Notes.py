

## Each file here should have everything needed to use the new module for atleast the main uses.
## Everything else is most like handy tools.

## There might be some things to do with the episodes indexer since trakt manager is coded there also.
## But i havent actually began to work on my episodes indexer yet so im not sure lol.

## Ive also included a tmdb pic for ya incase you wanna use the image like i do. ('tmdb.png')
## If ya dont use it then you will want to go thru my changes and switch the image code to something else.

### Theres also one more thing you need to add in order for things to work.
### Thats this def needing to be tossed in your control module.
### ( Or you could just modify my authTMDb def to not use it lmao. )

"""

def okDialog(message, heading=addonInfo('name')):
    return dialog.ok(heading, message)

"""

## If ya happen to make some improvements or whatnot to the new module feel free to share em with me or note em in your changelog lol.


##############################################
##############################################


##### Heres some random url list i slapped together a week or so ago that ya might want lol.


### Custom Indexers Maybe or Ghetto Scrapers

https://watchmonkonline.com/other-webites/
# This site has a bunch of other show sites to scrape.



### Movies / TV Series

#Made Maybe.
https://yifytv.top
https://vmovee.watch


https://vexmovies.space
# uses gomo.to

https://database.gdriveplayer.us/movie.php
https://database.gdriveplayer.us/series.php

https://watchseriess.net

https://1movies.life
https://5movies.vip
https://6movies.net
https://123movies.unblockninja.com
https://123movieweb.com
https://247movie.net
https://2213films.com
https://aa01.net
https://afdah.info
https://ask4movie.cc
https://attacker.tv
https://azm.to
https://batflix.org
https://bemovies.to
https://best-movies.watch
https://bflix.to
https://bluray7.com
https://bmovies.so
https://bs.to
https://cine-calidad.com
https://cine.to
https://cineb.net
https://cinebloom.me
https://cmovies.ac
https://coronamovies.net
https://crocovid.com
https://cuevana2.io

https://doomovies.ga
https://dopebox.net
https://dosmovies.com
https://dutafilm.quest
https://emovies.io
https://eprojectfreetv.us
https://europixhd.pro
https://ev01.to
https://f2movies.to
https://fboxtv.com
https://filmcomplet.vip
https://filmstreaming1vf.co
https://flixgo.me
https://flixmov.cc
https://flixtor.to
https://fmovies.to
https://fullepisodes.biz
https://goldesel.sx
https://gomovies-online.cam
https://gomoviz.co
https://goojara.to
https://gostream.site
https://gostream.to
https://hdbest.net
https://hdm.to
https://hdmovie2.com
https://hdmovie8.com
https://hdonline.eu
https://hds.club
https://hds.fm
https://himovies.to
https://hkdrama.to
https://hotpelis.com
https://katmoviehd.sk
https://kinoz.to
https://kumfimovies.com
https://layarkita.xyz
https://libertyvf.bz
https://lookmovie.io
https://m4ufree.tv
https://main.dailyflix.one
https://miradetodo.co
https://mixedmovie.com
https://mkvking.me
https://movie123.club
https://movieforfree.co
https://movies7.to
https://moviesjoy.to
https://moviestars.to
https://moviewatcher.is
https://moxox.com
https://musichq.net
https://myflixer.to
https://mywatchseries.stream
https://new-primewire.com
https://nowmovies.is
https://noxx.is
https://ohmovies.co
https://onionplay.uk
https://papystreaming.net
https://pelisplus.me
https://pinoymoviepedia.ru
https://pinoymovieshub.su
https://primewire.li
https://projectfreetv.fun
https://putlocker.to
https://putlockers.gg
https://quedustreaming.com
https://rainierland.to
https://rarefilmm.com
https://ronemo.com
https://s.to
https://serienjunkies.org
https://series9.ac
https://seriespapaya.me
https://sflix.to
https://soapgate.org
https://sockshare1.com
https://solarmovie.cr
https://spacemov.me
https://streamcr.vip
https://streamlord.com
https://streamm4u.com
https://supernova.to
https://swatchseries.ru
https://the123movies.eu
https://theflixer.tv
https://themoviebay.net
https://tinyzonetv.to
https://to123movies.cc
https://topeuropix.site
https://topnow.se
https://uwatchfree.pe








# CFscrape Blocked

https://watchseri.net



# Checked Out a Bit

https://vikv.net
https://vumoo.to
https://watchit99.com
https://winnoise.com
https://yesmoviesgo.com
https://yomovies.pe
https://zmovies.cc
https://zoechip.com


#######################################################
#######################################################


### Anime / Cartoons


https://1anime.to
https://9anime.to
https://anime2you.de/streams
https://anime8.ru
https://animebam.se
https://animedao.to
https://animeflv.net
https://animehub.ac
https://animekisa.tv
https://animelon.com
https://animeowl.net
https://animepahe.com
https://animerush.tv
https://animesimple.com
https://animesuge.io
https://animetake.tv
https://animetv.ge
https://animeultima.to
https://animevibe.wtf
https://animixplay.to
https://animumu.ga
https://aniwatch.me
https://aniwatcher.com
https://b98.tv
https://cartoonson.net
https://gogoanime.pe
https://kawaiifu.com
https://kickassanime.ro
https://kimcartoon.si
https://kiss-anime.ws
https://kissasian.ac
https://kisscartoon.sh
https://randaris.app
https://ryuanime.com
https://serieslan.com
https://simplyaweeb.com/series
https://streamani.net
https://supercartoons.net
https://thewatchcartoononline.tv
https://topcartoons.tv
https://twist.moe
https://vostfree.tv
https://wcoforever.com
https://wcostream.com
https://zoro.to/home


#######################################################
#######################################################


### Music / Radio


https://cmd.to
https://di.fm
https://everynoise.com/everynoise1d.cgi
https://jetsetradio.live
https://keygenmusic.tk
https://nightride.fm
https://plaza.one
https://podbay.fm
https://poolsuite.net
https://radio.garden
https://rainwave.cc
https://retrowave.ru
https://slider.kz
https://soundcloud.com
https://streamsquid.com


#######################################################
#######################################################


### Livestreams / IPTV


https://123tv.live
https://allsprk.tv
https://bitwave.tv
https://cytu.be
https://d.live
https://ip2.network
https://lmshows.se
https://robotstreamer.com
https://sessionslive.com
https://stream4free.live
https://streamwat.ch
https://theta.tv
https://twitch.tv
https://ustream.to
https://ustv247.tv
https://ustvgo.tv
https://vaughn.live
https://volume.com
https://youtube.com/live


#######################################################
#######################################################


### Sports / Esports


https://6streams.tv
https://720pstream.tv
https://bilasport.net/schedule.html
https://boxingstreams.cc
https://channelstream.watch
https://crackstreams.gg
https://cricfree.sc
https://daddylive.me
https://dubsports.to
https://footybite.cc
https://formula1stream.cc
https://fullfight.video
https://live-nba.stream
https://live-nfl.stream
https://live-nhl.stream
https://live.mma-streams.live
https://liveonscore.tv
https://mamahd.best
https://mlb-live.stream
https://mlbshow.com
https://mygoaltv.org
https://nbabite.com
https://nflbite.com
https://nflstreams.to
https://nhl66.ir
https://nhlbite.com
https://olympicstreams.me
https://onhockey.tv
https://raceday.watch
https://redditmlbstreams.live
https://redditnhlstreams.com
https://ripple.stream
https://rnbastreams.com
https://robosports.ir
https://sporthd.live
https://sportsala.cc
https://sportsbay.org
https://sportsonline.to
https://sportsurge.net
https://vipbox.lc
https://viprow.me
https://watchwrestling.la
https://worldcupfootball.me
https://wwestreams.cc
https://yrsprts.stream







