# -*- coding: utf-8 -*-

from six.moves.urllib_parse import parse_qs, urlencode

from resources.lib.modules import client
from resources.lib.modules import client_utils
from resources.lib.modules import cleantitle
from resources.lib.modules import scrape_sources
#from resources.lib.modules import log_utils


class source:
    def __init__(self):
        self.results = [] # This top row is "Active".
        self.domains = ['beta.myvid.one', 'get.myvideolinks.net', 'dl.myvideolinks.net', 'new.myvideolinks.net',
            'to.myvideolinks.net', 'go.myvideolinks.net', 'net.myvideolinks.net', 'forums.myvideolinks.net', 'myvideolinks.net'
        ]
        self.base_link = 'https://beta.myvid.one'
        self.search_link = '/?s=%s'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            #log_utils.log('movie', 1)
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            #log_utils.log('tvshow', 1)
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            #log_utils.log('episode', 1)
            return


    def sources(self, url, hostDict):
        try:
            if url == None:
                return self.results
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            season, episode = (data['season'], data['episode']) if 'tvshowtitle' in data else ('0', '0')
            year = data['premiered'].split('-')[0] if 'tvshowtitle' in data else data['year']
            hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']
            search = '%s %s' % (title, hdlr) if 'tvshowtitle' in data else data['imdb']
            search_url = self.base_link + self.search_link % cleantitle.get_plus(search)
            search_html = client.request(search_url)
            #if '<iframe' in search_html:  ##  Pulled since the current row of active sites dont seem to use this anyways.
                #new_url = client_utils.parseDOM(search_html, 'iframe', ret='src')[0]
                #new_base_link = new_url[:-1] if new_url.endswith('/') else new_url
                #search_url = new_base_link + self.search_link % cleantitle.get_plus(search)
                #search_html = client.request(search_url)
            search_result = client_utils.parseDOM(search_html, 'article')
            search_result = [(client_utils.parseDOM(i, 'a', ret='href'), client_utils.parseDOM(i, 'a')) for i in search_result]
            search_result = [(i[0][0], i[1][0]) for i in search_result if len(i[0]) > 0 and len(i[1]) > 0]
            result_urls = [i[0] for i in search_result if (title.lower() and hdlr.lower() in i[1].lower())]
            for result_url in result_urls:
                try:
                    page_html = client.request(result_url)
                    page_links = client_utils.parseDOM(page_html, 'a', attrs={'class': 'autohyperlink'}, ret='href')
                    page_links += client_utils.parseDOM(page_html, 'iframe', ret='src')
                    for link in page_links:
                        if any(i in link for i in (['imdb.com', 'youtube.com', 'turbobit.net', 'streamzz.to'] or self.domains)):
                            continue
                        for source in scrape_sources.process(hostDict, link):
                            if source['source'] in str(self.results):
                                continue
                            self.results.append(source)
                except:
                    #log_utils.log('sources', 1)
                    pass
            return self.results
        except:
            #log_utils.log('sources', 1)
            return self.results


    def resolve(self, url):
        return url


