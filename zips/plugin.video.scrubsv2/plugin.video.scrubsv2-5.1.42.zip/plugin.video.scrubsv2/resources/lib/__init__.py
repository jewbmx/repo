#

### Dev Shit Saved.


#except Exception:
#from resources.lib.modules import log_utils
#log_utils.log('Scraper Testing starting url: \n' + str(url))
#log_utils.log('Scraper Testing starting url: \n' + repr(url))
#log_utils.log('def', 1)


# if not url: return
# if url == None: return sources


# link = "https:" + link if link.startswith('//') else link
#link += '|Referer=%s/&User-Agent=iPad' % self.base_link

# url = url.replace('//sexhd.co/', '//fembed.com/') if '//sexhd.co/' in url else url
# url = url.replace('/f/', '/v/') if '//fembed.com/' in url or '//sexhd.co/' in url else url


# results_limit = 30
# if results_limit < 1: continue
# else: results_limit -= 1

# if url in str(self.results): continue
# if host in str(self.results): continue

# from resources.lib.modules import source_utils
# if source_utils.host_limit == 'true' and host in str(self.results): continue
# if source_utils.host_limit == 'true' and source['source'] in str(self.results): continue
# sources = []
# if source_utils.host_limit == 'true' and hoster in str(sources): continue
# else: sources.append(hoster)
# from resources.lib.modules import scrape_sources
# if scrape_sources.check_host_limit(source['source'], self.results):


#def request(url, close=True, redirect=True, error=False, verify=True, post=None, headers=None, mobile=False, XHR=False,
#            limit=None, referer=None, cookie=None, compression=False, output='', timeout='10', as_bytes=False):
# from resources.lib.modules import client
# url = client.request(url, output='geturl')
# self.cookie = client.request(self.base_link, output='cookie')
# html = client.request(url, cookie=self.cookie)
# html = client.request(url, output='json')
# html = client.request(url, output='json', timeout='30')
# html = client.request(url)
# html = client.scrapePage(url).text


# from resources.lib.modules import cleantitle
# cleantitle.geturl(title)
# cleantitle.get_under(title)
# cleantitle.get_dash(title)
# cleantitle.get_plus(title)
# cleantitle.get_utf8(title)


# from resources.lib.modules import source_utils
# return source_utils.strip_domain(url)
# valid, host = source_utils.checkHost(url, hostDict)
# valid, host = source_utils.is_host_valid(host, hostDict)
# quality, info = source_utils.get_release_quality(link, info)


#from resources.lib.modules import scrape_sources
#for source in scrape_sources.process(hostDict, link, host=None, info=None): sources.append(source)
#scrape_sources.rescrape(url, regex=None)
#scrape_sources.prepare_link(url)


# SAVED to be stored in module for example use.
# if not source_utils.is_anime('show', 'tvdb', tvdb): return


