# -*- coding: UTF-8 -*-

import re

from six.moves.urllib_parse import parse_qs, urlencode

from resources.lib.modules import client
from resources.lib.modules import client_utils
from resources.lib.modules import cleantitle
from resources.lib.modules import source_utils
#from resources.lib.modules import log_utils


class source:
    def __init__(self):
        self.results = []
        self.domains = ['tvmovieflix.com']
        self.base_link = 'https://tvmovieflix.com'
        self.search_link = '/?s=%s'
        self.notes = 'Has tv shows but too high to code it right now lol, its lookin tricky.'


    def movie(self, imdb, tmdb, title, localtitle, aliases, year):
        url = {'imdb': imdb, 'title': title, 'aliases': aliases, 'year': year}
        url = urlencode(url)
        return url


    def sources(self, url, hostDict):
        try:
            if url is None:
                return self.results
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            aliases = eval(data['aliases'])
            title = data['title']
            year = data['year']
            search_url = self.base_link + self.search_link % cleantitle.get_plus(title)
            html = client.scrapePage(search_url).text
            r = client_utils.parseDOM(html, 'div', attrs={'id': r'post-.*?'})
            r = [(client_utils.parseDOM(i, 'a', attrs={'class': 'title'}, ret='href'), client_utils.parseDOM(i, 'a', attrs={'class': 'title'}), re.findall('<span>(\d{4})</span>', i)) for i in r]
            r = [(i[0][0], i[1][0], i[2][0]) for i in r if len(i[0]) > 0 and len(i[1]) > 0 and len(i[2]) > 0]
            url = [i[0] for i in r if cleantitle.match_alias(i[1], aliases) and cleantitle.match_year(i[2], year)][0]
            page = client.scrapePage(url).text
            results = client_utils.parseDOM(page, 'div', attrs={'id': 'manual'}, ret='onclick')
            for result in results:
                try:
                    link = re.findall(r'''loadEmbed\(['"]([^'"]+)['"]\)''', result)[0]
                    if not (link.startswith('http') or link.startswith('//')):
                        continue
                    elif ('tvmovieflix' in link):
                        continue
                    elif 'realtalksociety' in link:
                        #link += '|Referer=https://realtalksociety.com/&User-Agent=iPad'
                        #self.results.append({'source': 'realtalksociety', 'quality': quality, 'info': info, 'url': link, 'direct': True})
                        continue # blocked for now because playing this seems to lag out everything.
                    else:
                        valid, host = source_utils.is_host_valid(link, hostDict)
                        quality, info = source_utils.get_release_quality(link, link)
                        self.results.append({'source': host, 'quality': quality, 'info': info, 'url': link, 'direct': False})
                except:
                    #log_utils.log('sources', 1)
                    pass
            return self.results
        except:
            #log_utils.log('sources', 1)
            return self.results


    def resolve(self, url):
        return url


"""


https://tvmovieflix.com/fast-x/

<div id="servers">
    <div class="note">
        If current server doesn't work please try other servers below.</div>
                                        <div id="manual" class="server FILEMOON" onclick="loadEmbed('https://filemoon.sx/e/guefnzm452un/F.X.2023.720p.V3.Clean.Cam.X264.Will1869.mkv');">
        <span>Server</span>
        <div>FILEMOON</div>
    </div>
                <div id="manual" class="server TVMF " onclick="loadEmbed('https://realtalksociety.com/videox/fastxv32023.mp4');">
        <span>Server</span>
        <div>TVMF </div>
    </div>

or...

var Servers = {
    "post_id":"1870",
    "id":"385687",
    "imdb_id":"tt5433140",
    "image":"\/\/image.tmdb.org\/t\/p\/original\/cEyhk8tZWubni71M6plwLMQFOIX.jpg",
    "vote_average":"6.7",
    "site":"https:\/\/tvmovieflix.com\/wp-content\/themes\/fmovie",
    "domain":"https:\/\/tvmovieflix.com\/",
    "youtube_id":"kshxFw49kaI",
    "mp4":"https:\/\/tvmovieflix.com\/wp-content\/plugins\/fmovie-core\/player\/embed.php?embed=1870",
    "upcloud":"https:\/\/tvmovieflix.com\/wp-content\/plugins\/fmovie-core\/player\/flix.php?id=1870",
    "premium":"https:\/\/tvmovieflix.com\/api\/movie.php?imdb=tt5433140",
    "embedru":"\/\/www.2embed.to\/embed\/imdb\/movie?id=tt5433140",
    "superembed":"https:\/\/tvmovieflix.com\/wp-content\/plugins\/fmovie-core\/player\/player.php?video_id=tt5433140",
    "svetacdn":"\/\/5190.svetacdn.in\/QoohkAG3qSXu?imdb_id=tt5433140",
    "vidsrc":"\/\/vidsrc.me\/embed\/tt5433140",
    "openvids":"\/\/openvids.io\/movie\/tt5433140",
    "autoembed":"disable"
};


from another movie...

loadEmbed sends you to these items by keys.

var Servers = {
    "post_id":"755",
    "id":"436270",
    "imdb_id":"tt6443346",
    "image":"\/\/image.tmdb.org\/t\/p\/original\/bQXAqRx2Fgc46uCVWgoPz5L5Dtr.jpg",
    "vote_average":"7.3",
    "site":"https:\/\/tvmovieflix.com\/wp-content\/themes\/fmovie",
    "domain":"https:\/\/tvmovieflix.com\/",
    "youtube_id":"I9B6rwW35GQ",
    "mp4":"https:\/\/tvmovieflix.com\/wp-content\/plugins\/fmovie-core\/player\/embed.php?embed=755",
    "upcloud":"https:\/\/tvmovieflix.com\/wp-content\/plugins\/fmovie-core\/player\/flix.php?id=755",
    "premium":"https:\/\/tvmovieflix.com\/api\/movie.php?imdb=tt6443346",
    "embedru":"\/\/www.2embed.to\/embed\/imdb\/movie?id=tt6443346",
    "superembed":"https:\/\/tvmovieflix.com\/wp-content\/plugins\/fmovie-core\/player\/player.php?video_id=tt6443346",
    "svetacdn":"\/\/5190.svetacdn.in\/QoohkAG3qSXu?imdb_id=tt6443346",
    "vidsrc":"\/\/vidsrc.me\/embed\/tt6443346",
    "openvids":"\/\/openvids.io\/movie\/tt6443346",
    "autoembed":"enable"
};


"""


