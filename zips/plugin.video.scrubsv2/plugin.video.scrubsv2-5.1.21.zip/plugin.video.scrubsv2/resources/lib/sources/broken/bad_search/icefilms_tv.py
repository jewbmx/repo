# -*- coding: utf-8 -*-

import re
import requests

from six.moves.urllib_parse import parse_qs, urlencode

from resources.lib.modules import client
from resources.lib.modules import client_utils
from resources.lib.modules import cleantitle
from resources.lib.modules import scrape_sources
#from resources.lib.modules import log_utils


class source:
    def __init__(self):
        self.results = []
        self.domains = ['icefilms.tv']
        self.base_link = 'https://icefilms.tv'
        #self.search_link = '/search/%s/1'
        self.search_link = 'https://www.startpage.com/do/search?q=%s+site:icefilms.tv'


    def movie(self, imdb, title, localtitle, aliases, year):
        url = {'imdb': imdb, 'title': title, 'aliases': aliases, 'year': year}
        url = urlencode(url)
        return url


    """ ### Removed for google search use since google search doesnt seem to find the shows.
    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        url = {'imdb': imdb, 'tvshowtitle': tvshowtitle, 'aliases': aliases, 'year': year}
        url = urlencode(url)
        return url


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        if not url:
            return
        url = parse_qs(url)
        url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
        url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
        url = urlencode(url)
        return url
    """


    def sources(self, url, hostDict):
        try:
            if url == None:
                return self.results
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            aliases = eval(data['aliases'])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            season, episode = (data['season'], data['episode']) if 'tvshowtitle' in data else ('0', '0')
            year = data['premiered'].split('-')[0] if 'tvshowtitle' in data else data['year']
            imdb = data['imdb']
            #url = self.base_link + self.search_link % cleantitle.get_plus(title)
            ### Google search code start..
            check_title = '%s (%s)' % (title, year)
            check_title = cleantitle.get_plus(check_title)
            url = self.search_link % cleantitle.get_plus(title)
            html = client.request(url, headers=client.dnt_headers)
            r = client_utils.parseDOM(html, 'div', attrs={'class': 'w-gl__result-second-line-container'})
            r = zip(client_utils.parseDOM(r, 'a', ret='href'), client_utils.parseDOM(r, 'h3'))
            results = [(i[0], i[1]) for i in r if len(i[0]) > 0 and len(i[1]) > 0]
            url = [i[0] for i in results if check_title in cleantitle.get_plus(i[1])][0]
            ### Google search code ends.
            self.cookie = client.request(self.base_link, output='cookie', timeout='5')
            #r = client.request(url, cookie=self.cookie)
            #r = client_utils.parseDOM(r, 'div', attrs={'class': 'movie'})
            #r = zip(client_utils.parseDOM(r, 'a', ret='href'), client_utils.parseDOM(r, 'div', attrs={'class': 'title'}), client_utils.parseDOM(r, 'div', attrs={'class': 'year'}))
            #r = [(i[0], i[1], i[2]) for i in r]
            #url = [i[0] for i in r if cleantitle.match_alias(i[1], aliases) and cleantitle.match_year(i[2], year, data['year'])][0]
            #if url == None:
                #raise Exception()
            #if 'tvshowtitle' in data:
                #url = self.base_link + url + '/season/%s/episode/%s' % (season, episode)
            #else:
                #url = self.base_link + url
            r = client.request(url, cookie=self.cookie)
            customheaders = {'User-Agent': client.UserAgent, 'Referer': url, 'Cookie': self.cookie}
            streams = re.findall("get\('(.+?)', {(.+?)}, function", r)
            for stream, id in streams:
                try:
                    params = '{%s}' % id
                    html = requests.get(self.base_link + stream, headers=customheaders, params=params).text
                    link = client_utils.parseDOM(html, 'iframe', ret='src')[0]
                    link = link + imdb if not imdb in link else link
                    if self.base_link in link:
                        try:
                            link = requests.get(link, headers=customheaders).url
                        except:
                            pass
                    for source in scrape_sources.process(hostDict, link):
                        self.results.append(source)
                except:
                    pass
            return self.results
        except:
            #log_utils.log('sources', 1)
            return self.results


    def resolve(self, url):
        return url


