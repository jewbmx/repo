# -*- coding: UTF-8 -*-

import re

from six.moves.urllib_parse import parse_qs, urlencode

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import client_utils
from resources.lib.modules import scrape_sources
from resources.lib.modules import log_utils


class source:
    def __init__(self):
        self.results = []
        self.domains = ['tvmovieflix.com']
        self.base_link = 'https://tvmovieflix.com'
        self.search_link = '/?s=%s'
        self.notes = 'Still needs work. Has tv shows but too high to code it right now lol, its lookin tricky.'


    def movie(self, imdb, tmdb, title, localtitle, aliases, year):
        url = {'imdb': imdb, 'title': title, 'aliases': aliases, 'year': year}
        url = urlencode(url)
        return url


    def sources(self, url, hostDict):
        try:
            if not url:
                return self.results
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            aliases = eval(data['aliases'])
            title = data['title']
            year = data['year']
            search_url = self.base_link + self.search_link % cleantitle.get_plus(title)
            html = client.scrapePage(search_url).text
            r = client_utils.parseDOM(html, 'div', attrs={'id': r'post-.*?'})
            r = [(client_utils.parseDOM(i, 'a', attrs={'class': 'title'}, ret='href'), client_utils.parseDOM(i, 'a', attrs={'class': 'title'}), re.findall('<span>(\d{4})</span>', i)) for i in r]
            r = [(i[0][0], i[1][0], i[2][0]) for i in r if len(i[0]) > 0 and len(i[1]) > 0 and len(i[2]) > 0]
            url = [i[0] for i in r if cleantitle.match_alias(i[1], aliases) and cleantitle.match_year(i[2], year)][0]
            log_utils.log('url: '+repr(url))
            page = client.scrapePage(url).text
            try:
                results = client_utils.parseDOM(page, 'div', attrs={'id': 'manual'}, ret='onclick')
                for result in results:
                    try:
                        log_utils.log('result: '+repr(result))
                        link = re.findall(r'''loadEmbed\(['"]([^'"]+)['"]\)''', result, re.DOTALL | re.IGNORECASE)[0]
                        link = client_utils.replaceHTMLCodes(link)
                        if not (link.startswith('http') or link.startswith('//')):
                            continue
                        elif ('tvmovieflix' in link):
                            continue
                        elif 'realtalksociety' in link:
                            item = scrape_sources.make_direct_item(hostDict, link, host=None, info=None, referer='https://realtalksociety.com/', prep=True)
                            if item:
                                if not scrape_sources.check_host_limit(item['source'], self.results):
                                    self.results.append(item)
                        else:
                            for source in scrape_sources.process(hostDict, link):
                                if scrape_sources.check_host_limit(source['source'], self.results):
                                    continue
                                self.results.append(source)
                    except:
                        log_utils.log('sources', 1)
                        pass
            except:
                log_utils.log('sources', 1)
                pass
            try:
                servers = re.findall(r'''var\s+Servers\s*=\s*\{([^\]]+)}''', page, re.DOTALL | re.IGNORECASE)[0]
                links = re.findall(r''':['"]([^'"]+)['"]''', servers, re.DOTALL | re.IGNORECASE)
                for link in links:
                    try:
                        link = client_utils.replaceHTMLCodes(link)
                        if not (link.startswith('http') or link.startswith('//')):
                            continue
                        if 'tvmovieflix' in link:
                            continue
                        if 'realtalksociety' in link:
                            item = scrape_sources.make_direct_item(hostDict, link, host=None, info=None, referer='https://realtalksociety.com/', prep=True)
                            if item:
                                if not scrape_sources.check_host_limit(item['source'], self.results):
                                    self.results.append(item)
                        else:
                            for source in scrape_sources.process(hostDict, link):
                                if scrape_sources.check_host_limit(source['source'], self.results):
                                    continue
                                self.results.append(source)
                    except:
                        log_utils.log('sources', 1)
                        pass
            except:
                log_utils.log('sources', 1)
                pass
            return self.results
        except:
            log_utils.log('sources', 1)
            return self.results


    def resolve(self, url):
        return url


