# -*- coding: utf-8 -*-

import re

from six.moves.urllib_parse import parse_qs, urlencode

from resources.lib.modules import client
from resources.lib.modules import client_utils
from resources.lib.modules import cleantitle
#from resources.lib.modules import log_utils
from resources.lib.modules import source_utils
from resources.lib.modules import scrape_sources


class source:
    def __init__(self):
        self.results = []
        self.domains = ['mywatchseries.fun']
        self.base_link = 'https://mywatchseries.fun'
        self.search_link = '/search/%s'
        self.notes = 'swap to "hard coded" urls since the search has blockage.'


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            link = self.base_link + '/tv-series/' + cleantitle.get_dash(tvshowtitle)
            return link
            """
            search_title = cleantitle.get_dash(tvshowtitle)
            check1_title = '%s (%s)' % (tvshowtitle, year)
            check1_title = cleantitle.get_dash(check1_title)
            check2_title = cleantitle.get_dash(tvshowtitle)
            link = self.base_link + self.search_link % search_title
            html = client.request(link)
            regex = 'class="film-poster-img lazyload"> <a href=(.+?) title="(.+?)" class="film-poster-ahref flw-item-tip">'
            results = re.compile(regex).findall(html)
            for result_url, result_title in results:
                if check1_title == cleantitle.get_dash(result_title):
                    return result_url
                elif check2_title == cleantitle.get_dash(result_title):
                    return result_url
            return
            """
        except:
            #log_utils.log('tvshow', 1)
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            link = url + '-season-%s-episode-%s/' % (season, episode)
            return link
            """
            result_html = client.request(url)
            search_url = '-season-%s-episode-%s/' % (season, episode)
            results = client_utils.parseDOM(result_html, 'a', ret='href')
            result_url = [i for i in results if search_url in i][0]
            return result_url
            """
        except:
            #log_utils.log('episode', 1)
            return


    def sources(self, url, hostDict):
        try:
            if url == None:
                return self.results
            html = client.request(url)
            try:
                links = client_utils.parseDOM(html, 'iframe', ret='src')
                for link in links:
                    if 'disableadblock.com' in link:
                        continue
                    for source in scrape_sources.process(hostDict, link):
                        self.results.append(source)
            except:
                #log_utils.log('sources', 1)
                pass
            try:
                try:
                    ext_links = client_utils.parseDOM(html, 'ul', attrs={'id': 'video-links'})[0]
                except:
                    ext_links = client_utils.parseDOM(html, 'ul', attrs={'id': 'videolinks'})[0]
                links = client_utils.parseDOM(ext_links, 'a', ret='href')
                for link in links:
                    host = re.findall('/open/link/.+?/(.+?)/', link)[0]
                    if host in str(self.results):
                        continue
                    valid, host = source_utils.is_host_valid(host, hostDict)
                    if valid:
                        link = self.base_link + link
                        self.results.append({'source': host, 'quality': 'SD', 'url': link, 'direct': False})
            except:
                #log_utils.log('sources', 1)
                pass
            return self.results
        except:
            #log_utils.log('sources', 1)
            return self.results


    def resolve(self, url):
        if any(x in url for x in self.domains):
            html = client.request(url)
            try:
                link = client_utils.parseDOM(html, 'iframe', ret='src')[0]
                return link
            except:
                match = re.compile(r'"(/open/site/.+?)"', re.I|re.S).findall(html)[0]
                link = self.base_link + match
                link = client.request(link, output='geturl')
                return link
        else:
            return url


