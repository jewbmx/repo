# -*- coding: utf-8 -*-

import re
import sys
import random

from six.moves.urllib_parse import parse_qs, urlencode

from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import log_utils


class iptv:
    def __init__(self):
        self.base_link = 'http://www.sdw-net.me'
        self.channels = []
        self.list = []
        self.ARAB_TV = [
            {"title": "Al Jazeera Arabic", "url": "/channels/Al-Jazeera-Arabic.html", "image": "/product_images/n/253/aljazeera__84338_thumb.png"},
            {"title": "Al Jazeera Documentary", "url": "/channels/Al-Jazeera-Documentary.html", "image": "/product_images/b/160/Al_Jazeera_Documentary_Channel__34510_thumb.png"},
            {"title": "BBC Arabic", "url": "/channels/BBC%252dArabic.html", "image": "/product_images/x/782/bbc_arabic__71485_thumb.PNG"},
            {"title": "Sky News Arab", "url": "/channels/Sky-News-Arab.html", "image": "/product_images/z/091/Sky_News_Arabia_logo__60552_thumb.png"}
        ]
        self.FRENCH_TV = [
            {"title": "6ter", "url": "/channels/6ter.html", "image": "/product_images/l/385/6ter_2012__99091_thumb.png"},
            {"title": "Animaux", "url": "/channels/Animaux.html", "image": "/product_images/y/244/animaux__45071_thumb.jpg"},
            {"title": "BFM.TV", "url": "/channels/BFM.TV.html", "image": "/product_images/j/523/BFMTV__21435_thumb.png"},
            {"title": "Chasse et Peche", "url": "/channels/Chasse-et-P%C3%AAche.html", "image": "/product_images/h/485/chasse_et_peche__73555_thumb.jpg"},
            {"title": "Discovery FR", "url": "/channels/Discovery-FR.html", "image": "/product_images/o/710/discovery_us__36214_thumb.jpg"},
            {"title": "Euronews FR", "url": "/channels/Euronews%252dFR.html", "image": "/product_images/f/716/euronews__96297_thumb.jpg"},
            {"title": "Eurosport1 FR", "url": "/channels/Eurosport1-FR.html", "image": "/product_images/g/221/eurosport__72244_thumb.jpg"},
            {"title": "FashionTV", "url": "/channels/FashionTV.html", "image": "/product_images/f/442/fashion_tv__10290_thumb.jpg"},
            {"title": "France 2", "url": "/channels/France-2.html", "image": "/product_images/y/747/france2__29267_thumb.jpg"},
            {"title": "France 3", "url": "/channels/France3.html", "image": "/product_images/j/518/france3__66917_thumb.jpg"},
            {"title": "France 4", "url": "/channels/France-4.html", "image": "/product_images/z/320/france4__06723_thumb.jpg"},
            {"title": "France 5", "url": "/channels/France-5.html", "image": "/product_images/x/498/france5__26772_thumb.jpg"},
            {"title": "France O", "url": "/channels/France-%C3%94.html", "image": "/product_images/n/983/france_o__96943_thumb.jpg"},
            {"title": "I-Tele", "url": "/channels/i%252dT%C3%A9l%C3%A9.html", "image": "/product_images/l/893/I-T%C3%A9l%C3%A9_2013__26199_thumb.png"},
            {"title": "L-Equipe-21", "url": "/channels/L%252dEquipe%252d21.html", "image": "/product_images/k/157/l_equipe_21_fr__45356_thumb.jpg"},
            {"title": "M 6", "url": "/channels/M-6.html", "image": "/product_images/t/686/m6__79935_thumb.jpg"},
            {"title": "RTS 1", "url": "/channels/RTS-1.html", "image": "/product_images/y/407/rts_un__92413_thumb.jpg"},
            {"title": "RTS Deux", "url": "/channels/RTS-Deux.html", "image": "/product_images/y/153/rts_deux__51855_thumb.jpg"},
            {"title": "TF1", "url": "/channels/TF1.html", "image": "/product_images/w/668/tf1__68155_thumb.jpg"},
            {"title": "W9", "url": "/channels/W9.html", "image": "/product_images/p/714/w9__56634_thumb.jpg"}
        ]
        self.GERMAN_TV = [
            {"title": "Das Erste", "url": "/channels/Das-Erste.html", "image": "/product_images/w/786/ard__19793_thumb.jpg"},
            {"title": "Deutsche Welle", "url": "/channels/Deutsche-Welle.html", "image": "/product_images/a/044/dw_tv__63402_thumb.jpg"},
            {"title": "Disney DE", "url": "/channels/Disney-DE.html", "image": "/product_images/y/352/disney_channel__26154_thumb.jpg"},
            {"title": "Eurosport", "url": "/channels/Eurosport.html", "image": "/product_images/r/279/eurosport__75580_thumb.jpg"},
            {"title": "Kabel Eins", "url": "/channels/Kabel-Eins.html", "image": "/product_images/t/152/kabel1__63893_thumb.jpg"},
            {"title": "KiKa", "url": "/channels/KiKa.html", "image": "/product_images/g/009/kinderkanal__49484_thumb.jpg"},
            {"title": "N TV", "url": "/channels/N-TV.html", "image": "/product_images/l/779/ntv_de__93235_thumb.jpg"},
            {"title": "ORF 2", "url": "/channels/ORF-2.html", "image": "/product_images/i/440/orf2__54577_thumb.jpg"},
            {"title": "ORF Eins", "url": "/channels/ORF-Eins.html", "image": "/product_images/q/474/orf1__10981_thumb.jpg"},
            {"title": "Phoenix", "url": "/channels/Phoenix.html", "image": "/product_images/x/727/Phoenix_Logo_2012.svg__42553_thumb.png"},
            {"title": "ProSieben", "url": "/channels/ProSieben.html", "image": "/product_images/j/009/pro7__88480_thumb.jpg"},
            {"title": "RBB Berlin", "url": "/channels/RBB-Berlin.html", "image": "/product_images/j/738/rbb_de__66295_thumb.jpg"},
            {"title": "RTL 2", "url": "/channels/RTL-2.html", "image": "/product_images/p/269/rtl__41751_thumb.jpg"},
            {"title": "RTL", "url": "/channels/RTL.html", "image": "/product_images/i/119/rtl__48257_thumb.jpg"},
            {"title": "Sat.1", "url": "/channels/Sat.1.html", "image": "/product_images/f/936/sat1__13963_thumb.jpg"},
            {"title": "Sixx", "url": "/channels/Sixx.html", "image": "/product_images/k/338/sixx__62175_thumb.jpg"},
            {"title": "Sky Sport2", "url": "/channels/Sky%252dSport2.html", "image": "/product_images/f/498/sky_de_sport_02_hd__85038_thumb.jpg"},
            {"title": "SSport 1", "url": "/channels/SSport-1.html", "image": "/product_images/p/154/Sky_Sport_1_off-air_2011__91616_thumb.png"},
            {"title": "Tagesschau24", "url": "/channels/tagesschau24.html", "image": "/product_images/f/462/301px-Tagesschau24-2012__84641_thumb.png"},
            {"title": "WDR Fernsehen", "url": "/channels/WDR-Fernsehen.html", "image": "/product_images/p/281/wdr_fernsehen_koln__11515_thumb.jpg"},
            {"title": "ZDF Neo", "url": "/channels/ZDF-Neo.html", "image": "/product_images/a/558/zdf_neo__47353_thumb.jpg"},
            {"title": "ZDF", "url": "/channels/ZDF.html", "image": "/product_images/l/154/zdf__67759_thumb.jpg"}
        ]
        self.ITALIAN_TV = [
            {"title": "Cielo TV", "url": "/channels/Cielo-TV.html", "image": "/product_images/c/953/cielo__18877_thumb.jpg"},
            {"title": "Rai 2", "url": "/channels/Rai2.html", "image": "/product_images/t/148/Rai_2_logo__79173_thumb.png"},
            {"title": "Rai 4", "url": "/channels/Rai4.html", "image": "/product_images/o/852/Rai_4_2010__78387_thumb.png"},
            {"title": "Rai 1", "url": "/channels/Rai-1.html", "image": "/product_images/m/362/Rai_1_logo__67635_thumb.png"},
            {"title": "Rai 3", "url": "/channels/Rai-3.html", "image": "/product_images/w/005/Rai_3_logo__60097_thumb.png"},
            {"title": "Rai 5", "url": "/channels/Rai-5.html", "image": "/product_images/a/799/Rai_5_logo__81811_thumb.png"},
            {"title": "Rai Movie", "url": "/channels/Rai-Movie.html", "image": "/product_images/l/506/RAI_Movie_2010_Logo__63887_thumb.png"},
            {"title": "Rai Sport", "url": "/channels/Rai-Sport.html", "image": "/product_images/x/320/1920px-Rai_Sport_-_Logo_2017__46337_thumb.png"},
            {"title": "RSI La 1", "url": "/channels/RSI%252dLa%252d1.html", "image": "/product_images/i/330/rsi_la1__95748_thumb.jpg"},
            {"title": "RSI La 2", "url": "/channels/RSI%252dLa%252d2.html", "image": "/product_images/q/536/rsi_la2__31571_thumb.jpg"},
            {"title": "SCalcio", "url": "/channels/SCalcio.html", "image": "/product_images/a/134/sky_it_calcio__42011_thumb.png"},
            {"title": "Sky Sport Uno", "url": "/channels/Sky-Sport%252dUno.html", "image": "/product_images/z/059/sky_iit_sport1__99735_thumb.jpg"},
            {"title": "Sky TG 24", "url": "/channels/Sky-TG-24.html", "image": "/product_images/u/637/SKY_TG24__09392_thumb.png"}
        ]
        self.NORDIC_TV = [
            {"title": "DR1", "url": "/channels/DR1.html", "image": "/product_images/l/503/DR1_logo_2013__12737_thumb.png"},
            {"title": "SVT 1", "url": "/channels/SVT.1.html", "image": "/product_images/j/839/svt_1__03141_thumb.jpg"},
            {"title": "SVT 2", "url": "/channels/SVT-2.html", "image": "/product_images/d/662/svt_2__30340_thumb.jpg"},
            {"title": "TV4 Sweden", "url": "/channels/TV4-Sweden.html", "image": "/product_images/k/588/tv4__72223_thumb.jpg"}
        ]
        self.SWISS_TV = [
            {"title": "RSI La 1", "url": "/channels/RSI%252dLa%252d1.html", "image": "/product_images/i/330/rsi_la1__95748_thumb.jpg"},
            {"title": "RSI La 2", "url": "/channels/RSI%252dLa%252d2.html", "image": "/product_images/q/536/rsi_la2__31571_thumb.jpg"},
            {"title": "RTS 1", "url": "/channels/RTS-1.html", "image": "/product_images/y/407/rts_un__92413_thumb.jpg"},
            {"title": "RTS Deux", "url": "/channels/RTS-Deux.html", "image": "/product_images/y/153/rts_deux__51855_thumb.jpg"},
            {"title": "SRF Eins", "url": "/channels/SRF-Eins.html", "image": "/product_images/p/122/srf_1_ch__27802_thumb.jpg"},
            {"title": "SRF Zwei", "url": "/channels/SRF-Zwei.html", "image": "/product_images/u/790/srf_2_ch__91017_thumb.png"}
        ]
        self.UK_TV = [
            {"title": "Animal Planet UK", "url": "/channels/Animal-Planet-UK.html", "image": "/product_images/w/160/Animal_Planet_logo_%28black_and_green%29__98995_thumb.png"},
            {"title": "BBC 1", "url": "/channels/BBC%252d1.html", "image": "/product_images/r/418/BBC_One_2002__20962_thumb.png"},
            {"title": "BBC 2", "url": "/channels/BBC-2.html", "image": "/product_images/x/270/BBC_Two.svg_%281%29__18552_thumb.png"},
            {"title": "BBC 3", "url": "/channels/BBC-3.html", "image": "/product_images/z/431/bbc3__58300_thumb.jpg"},
            {"title": "BBC 4", "url": "/channels/BBC-4.html", "image": "/product_images/u/402/bbc4__60255_thumb.jpg"},
            {"title": "BBC News", "url": "/channels/BBC%252dNews.html", "image": "/product_images/u/125/bbc_news__39343_thumb.jpg"},
            {"title": "BBC Wold News", "url": "/channels/BBC-Wold-News.html", "image": "/product_images/p/302/bbc_world__60450_thumb.jpg"},
            {"title": "Box Nation", "url": "/channels/Box%252dNation.html", "image": "/product_images/h/426/box_nation__84194_thumb.jpg"},
            {"title": "Capital", "url": "/channels/Capital.html", "image": "/product_images/r/954/Capital_TV_logo__27138_thumb.png"},
            {"title": "Cartoon Network UK", "url": "/channels/Cartoon%252dNetwork%252dUK.html", "image": "/product_images/x/048/cartoon_network__02584_thumb.jpg"},
            {"title": "CBS Action", "url": "/channels/CBS-Action.html", "image": "/product_images/k/353/cbs_action_uk__54811_thumb.png"},
            {"title": "CBS Drama", "url": "/channels/CBS.Drama.html", "image": "/product_images/u/097/cbs_drama_eu__13760_thumb.png"},
            {"title": "CBS Reality", "url": "/channels/CBS-Reality.html", "image": "/product_images/u/279/cbs_reality__44213_thumb.jpg"},
            {"title": "Channel 4", "url": "/channels/Channel%252d4.html", "image": "/product_images/s/715/channel4__56690_thumb.jpg"},
            {"title": "Channel 5", "url": "/channels/Channel-5.html", "image": "/product_images/m/671/channel5_uk__99265_thumb.jpg"},
            {"title": "Chelsea TV", "url": "/channels/Chelsea-TV.html", "image": "/product_images/s/436/chelsea_tv__40010_thumb.jpg"},
            {"title": "Comedy Central UK", "url": "/channels/Comedy-Central-UK.html", "image": "/product_images/u/379/comedy_central_us__55592__60778_thumb.jpg"},
            {"title": "Cycling 1", "url": "/channels/Cycling-1.html", "image": "/product_images/w/262/c-ing__88722_thumb.jpg"},
            {"title": "Cycling 2", "url": "/channels/Cycling2.html", "image": "/product_images/d/125/c-ing__51846_thumb.jpg"},
            {"title": "Dave", "url": "/channels/Dave.html", "image": "/product_images/q/672/dave__30048_thumb.jpg"},
            {"title": "Discovery History", "url": "/channels/Discovery-History.html", "image": "/product_images/q/707/Discovery_History_2010__01621_thumb.png"},
            {"title": "Discovery Investigation UK", "url": "/channels/Discovery-Investigation-UK.html", "image": "/product_images/x/369/investigation_discovery__87602_thumb.jpg"},
            {"title": "Discovery Science UK", "url": "/channels/Discovery-Science-UK.html", "image": "/product_images/t/726/Discovery_Science_h__96606_thumb.png"},
            {"title": "Discovery UK", "url": "/channels/Discovery%252dUK.html", "image": "/product_images/j/140/discovery_us__02242_thumb.jpg"},
            {"title": "Disney Channel UK", "url": "/channels/Disney%252dChannel%252dUK.html", "image": "/product_images/g/535/disney_channel__10345_thumb.jpg"},
            {"title": "E4", "url": "/channels/E4.html", "image": "/product_images/x/573/e4_uk__72574_thumb.jpg"},
            {"title": "E! Entertainment", "url": "/channels/E%21-Entertainment.html", "image": "/product_images/r/548/E%21_Logo_2012__59361_thumb.png"},
            {"title": "Euronews", "url": "/channels/Euronews.html", "image": "/product_images/l/724/euronews__73752_thumb.jpg"},
            {"title": "Film 4", "url": "/channels/Film-4.html", "image": "/product_images/v/827/film4__52400_thumb.jpg"},
            {"title": "Food Network UK", "url": "/channels/Food-Network-UK.html", "image": "/product_images/q/298/food_network_uk__02476_thumb.jpg"},
            {"title": "Gold Channel", "url": "/channels/Gold-Channel.html", "image": "/product_images/c/241/gold_black_background__91302_thumb.jpg"},
            {"title": "Heart TV", "url": "/channels/Heart-TV.html", "image": "/product_images/z/606/Heart_TV_logo__58712_thumb.png"},
            {"title": "History UK", "url": "/channels/History-UK.html", "image": "/product_images/z/917/history_europe__17235_thumb.jpg"},
            {"title": "ITV2", "url": "/channels/ITV%252d2.html", "image": "/product_images/x/104/itv2__44555_thumb.jpg"},
            {"title": "ITV3", "url": "/channels/ITV3.html", "image": "/product_images/k/294/itv3__61186_thumb.jpg"},
            {"title": "ITV4", "url": "/channels/ITV4.html", "image": "/product_images/r/387/itv4__95441_thumb.jpg"},
            {"title": "ITV", "url": "/channels/ITV.html", "image": "/product_images/p/615/itv_uk__27094_thumb.jpg"},
            {"title": "ITV.Be", "url": "/channels/ITV.Be.html", "image": "/product_images/x/968/ITVBe_logo_2014-__58951_thumb.png"},
            {"title": "London Live", "url": "/channels/London-Live.html", "image": "/product_images/v/648/london_live__38073_thumb.png"},
            {"title": "Manchester United TV", "url": "/channels/Manchester-United-TV.html", "image": "/product_images/i/675/mutv__18782_thumb.jpg"},
            {"title": "More 4", "url": "/channels/More-4.html", "image": "/product_images/w/935/more4__90180_thumb.jpg"},
            {"title": "Motors TV", "url": "/channels/Motors-TV.html", "image": "/product_images/s/922/MotorsTV-logo__73046_thumb.png"},
            {"title": "MTV Classic UK", "url": "/channels/MTV%252dClassic%252dUK.html", "image": "/product_images/z/697/MTV_Classic_logo_2013__65812_thumb.png"},
            {"title": "MTV Dance", "url": "/channels/MTV%252dDance.html", "image": "/product_images/x/506/MTV_Dance_2013__40554_thumb.png"},
            {"title": "MTV Hits", "url": "/channels/MTV-Hits.html", "image": "/product_images/b/347/MTV_Hits_Logo_2012__61325_thumb.png"},
            {"title": "MTV Rocks", "url": "/channels/MTV%252dRocks.html", "image": "/product_images/w/993/MTV_Rocks_logo_2013__21136_thumb.png"},
            {"title": "Nat Geo Wild UK", "url": "/channels/Nat-Geo-Wild-UK.html", "image": "/product_images/s/246/nat_geo_wild__16696_thumb.jpg"},
            {"title": "Premier", "url": "/channels/Premier.html", "image": "/product_images/i/771/Premier_Sports_logo__59689_thumb.png"},
            {"title": "Racing UK", "url": "/channels/Racing-UK.html", "image": "/product_images/h/544/racing_uk__87840_thumb.jpg"},
            {"title": "Really", "url": "/channels/Really.html", "image": "/product_images/c/248/Really_logo_2013__65352_thumb.png"},
            {"title": "RTE 1", "url": "/channels/RTE-1.html", "image": "/product_images/m/283/rte_one__12324_thumb.jpg"},
            {"title": "RTE 2", "url": "/channels/RTE-2.html", "image": "/product_images/c/249/rte_two__61649_thumb.jpg"},
            {"title": "Setanta", "url": "/channels/Setanta.html", "image": "/product_images/t/788/setanta_sports_ie__75006_thumb.jpg"},
            {"title": "Sky Atlantic", "url": "/channels/Sky-Atlantic.html", "image": "/product_images/t/541/sky_uk_atlantic__46552_thumb.jpg"},
            {"title": "Sky News", "url": "/channels/Sky-News.html", "image": "/product_images/j/542/sky_news__04995_thumb.jpg"},
            {"title": "Sky One", "url": "/channels/Sky-One.html", "image": "/product_images/a/865/sky_uk_1__64403_thumb.jpg"},
            {"title": "Sky Two", "url": "/channels/Sky-Two.html", "image": "/product_images/n/296/sky_uk_2__94151_thumb.jpg"},
            {"title": "TLC UK", "url": "/channels/TLC-UK.html", "image": "/product_images/x/771/TLC_USA_logo__08491_thumb.png"},
            {"title": "Travel Channel +1", "url": "/channels/Travel-Channel-%252b1.html", "image": "/product_images/w/588/Travel_Channel_HD_2013__76743_thumb.png"},
            {"title": "Tru TV", "url": "/channels/Tru-TV.html", "image": "/product_images/k/433/TruTV_logo_2014__16713_thumb.png"},
            {"title": "VH1 EU", "url": "/channels/VH1-EU.html", "image": "/product_images/k/656/VH1_logonew__46519_thumb.png"}
        ]
        self.USA_TV = [
            {"title": "A&E", "url": "/channels/A-%26-E.html", "image": "/product_images/h/192/ae_tv__99609_thumb.jpg"},
            {"title": "ABC 7 NY", "url": "/channels/ABC-7-NY.html", "image": "/product_images/b/900/wabc_abc7_new_york__26026_thumb.jpg"},
            {"title": "ABC Family", "url": "/channels/ABC%252dFamily.html", "image": "/product_images/t/232/abc_family__05204_thumb.jpg"},
            {"title": "ABC News", "url": "/channels/ABC%252dNews.html", "image": "/product_images/f/799/abc_news_now__18019_thumb.jpg"},
            {"title": "ABC", "url": "/channels/ABC.html", "image": "/product_images/q/639/abc27__39425_thumb.jpg"},
            {"title": "Al Jazeera America", "url": "/channels/Al-Jazeera-America.html", "image": "/product_images/r/030/Al_Jazeera_America_Logo__32655_thumb.png"},
            {"title": "AMC East", "url": "/channels/AMC%252dEast.html", "image": "/product_images/r/604/amc__85163_thumb.jpg"},
            {"title": "American Heroes", "url": "/channels/American-Heroes.html", "image": "/product_images/a/440/American_Heroes_Channel__12824_thumb.png"},
            {"title": "Animal Planet", "url": "/channels/Animal-Planet.html", "image": "/product_images/z/026/Animal_Planet_logo_%28black_and_green%29__59139_thumb.png"},
            {"title": "BBC America", "url": "/channels/BBC.America.html", "image": "/product_images/z/021/BBC_America__07523_thumb.png"},
            {"title": "BET East", "url": "/channels/BET-East.html", "image": "/product_images/e/316/BET_Logo__19751_thumb.png"},
            {"title": "Bloomberg", "url": "/channels/Bloomberg.html", "image": "/product_images/f/355/bloomberg__80284_thumb.jpg"},
            {"title": "Bravo US", "url": "/channels/Bravo-US.html", "image": "/product_images/g/338/bravo_us__11790_thumb.jpg"},
            {"title": "Cartoon Network", "url": "/channels/Cartoon-Network.html", "image": "/product_images/n/286/cartoon_network__82102_thumb.jpg"},
            {"title": "CBS 2 NY", "url": "/channels/CBS-2-NY.html", "image": "/product_images/a/024/wcbs_cbs2_new_york__91850_thumb.jpg"},
            {"title": "CBS 47", "url": "/channels/CBS-47.html", "image": "/product_images/z/021/cbs__60685_thumb.jpg"},
            {"title": "CBS News", "url": "/channels/CBS%252dNews.html", "image": "/product_images/i/269/CBS_News2__07317_thumb.jpg"},
            {"title": "CNN UK", "url": "/channels/CNN-UK.html", "image": "/product_images/j/051/cnn_international__19122_thumb.jpg"},
            {"title": "CNN", "url": "/channels/CNN.html", "image": "/product_images/p/470/cnn_usa__34139_thumb.jpg"},
            {"title": "Comedy Central", "url": "/channels/Comedy%252dCentral.html", "image": "/product_images/o/226/comedy_central_us__62938_thumb.jpg"},
            {"title": "CW 11 NY", "url": "/channels/CW-11-NY.html", "image": "/product_images/m/574/wpix_cw11_new_york__22440_thumb.jpg"},
            {"title": "CW East", "url": "/channels/CW-East.html", "image": "/product_images/r/672/CW_logo_color_v__09334_thumb.jpg"},
            {"title": "Discovery ID US", "url": "/channels/Discovery-ID-US.html", "image": "/product_images/w/036/investigation_discovery__91066_thumb.jpg"},
            {"title": "Discovery", "url": "/channels/Discovery.html", "image": "/product_images/k/583/discovery_us__51096_thumb.jpg"},
            {"title": "Disney Channel US", "url": "/channels/Disney-Channel-US.html", "image": "/product_images/e/907/disney_channel__34733_thumb.jpg"},
            {"title": "ESPN2", "url": "/channels/ESPN2.html", "image": "/product_images/a/831/ESPN2_logo__59298_thumb.png"},
            {"title": "ESPN.1", "url": "/channels/ESPN.1.html", "image": "/product_images/y/742/ESPN__66232_thumb.png"},
            {"title": "Food Network US", "url": "/channels/Food-Network-US.html", "image": "/product_images/z/857/food_network_uk__16280_thumb.jpg"},
            {"title": "FOX 2 St. Louis", "url": "/channels/FOX-2-St.-Louis.html", "image": "/product_images/v/930/KTVI_2_logo__11697_thumb.png"},
            {"title": "Fox 5 Washington DC", "url": "/channels/Fox-5-Washington-DC.html", "image": "/product_images/x/136/Wttg__90022_thumb.jpg"},
            {"title": "FOX 13 News Tampa Bay", "url": "/channels/FOX-13-News-Tampa-Bay.html", "image": "/product_images/e/939/WTVT_Fox_13_logo__37207_thumb.png"},
            {"title": "Golf TV", "url": "/channels/Golf-TV.html", "image": "/product_images/s/418/golf_channel_us__36323_thumb.jpg"},
            {"title": "Hallmark TV", "url": "/channels/Hallmark%252dTV.html", "image": "/product_images/m/968/Hallmark-Channel-The-Heart-of-TV-Logo__99555_thumb.jpg"},
            {"title": "HGTV", "url": "/channels/HGTV.html", "image": "/product_images/v/595/HGTV_logo_2015__20364_thumb.png"},
            {"title": "History US", "url": "/channels/History-US.html", "image": "/product_images/c/576/history_europe__24065_thumb.jpg"},
            {"title": "HLN", "url": "/channels/HLN.html", "image": "/product_images/z/904/hln__89483_thumb.jpg"},
            {"title": "KRON 4 News San Francisco", "url": "/channels/KRON-4-News-San-Francisco.html", "image": "/product_images/v/424/KRON_4_Main_Logo__41805_thumb.png"},
            {"title": "Lifetime US", "url": "/channels/Lifetime-US.html", "image": "/product_images/b/056/Lifetime_logo_2013__32042_thumb.png"},
            {"title": "MLB Network", "url": "/channels/MLB.Network.html", "image": "/product_images/o/660/mlb_network__27352_thumb.jpg"},
            {"title": "MSNBC News", "url": "/channels/MSNBC-News.html", "image": "/product_images/e/114/msnbc__44837_thumb.jpg"},
            {"title": "MTV", "url": "/channels/MTV.html", "image": "/product_images/w/104/MTV_Logo_2010__92640_thumb.png"},
            {"title": "NASA TV", "url": "/channels/NASA-TV.html", "image": "/product_images/m/506/nasa_tv_us__35798_thumb.jpg"},
            {"title": "NBA", "url": "/channels/NBA.html", "image": "/product_images/u/073/nba_tv__20518_thumb.jpg"},
            {"title": "NBC 4 NY", "url": "/channels/NBC-4-NY.html", "image": "/product_images/c/970/wnbc_nbc4_new_york__88786_thumb.jpg"},
            {"title": "NBC Sports", "url": "/channels/NBC.Sports.html", "image": "/product_images/q/063/nbc_sports_network__66246_thumb.jpg"},
            {"title": "NBC TV", "url": "/channels/NBC-TV.html", "image": "/product_images/w/554/nbc__14605_thumb.gif"},
            {"title": "NFL", "url": "/channels/NFL.html", "image": "/product_images/n/410/nfl_network__08611_thumb.jpg"},
            {"title": "NHL Network", "url": "/channels/NHL-Network.html", "image": "/product_images/v/462/NHL_Network_2011__53239_thumb.png"},
            {"title": "Nickelodeon", "url": "/channels/Nickelodeon.html", "image": "/product_images/w/877/Nickelodeon_logo_new__07923_thumb.png"},
            {"title": "Oprah Winfrey Network", "url": "/channels/Oprah-Winfrey-Network.html", "image": "/product_images/r/136/own__48299_thumb.jpg"},
            {"title": "Pac 12 Arizona", "url": "/channels/Pac-12-Arizona.html", "image": "/product_images/f/860/Pac-12_Networks_logo__13866_thumb.png"},
            {"title": "Pac 12 Bay Area", "url": "/channels/Pac-12-Bay-Area.html", "image": "/product_images/c/453/Pac-12_Networks_logo__07345_thumb.png"},
            {"title": "Pac 12 Los Angeles", "url": "/channels/Pac.12-Los-Angeles.html", "image": "/product_images/y/660/Pac-12_Networks_logo__02467_thumb.png"},
            {"title": "Pac 12 Mountain", "url": "/channels/Pac-12-Mountain.html", "image": "/product_images/n/028/Pac-12_Networks_logo__03916_thumb.png"},
            {"title": "Pac 12 Network", "url": "/channels/Pac-12-Network.html", "image": "/product_images/f/759/Pac-12_Networks_logo__13527_thumb.png"},
            {"title": "Pac 12 Oregon", "url": "/channels/Pac-12-Oregon.html", "image": "/product_images/d/706/Pac-12_Networks_logo__50740_thumb.png"},
            {"title": "Pac 12 Washington", "url": "/channels/Pac-12-Washington.html", "image": "/product_images/d/574/Pac-12_Networks_logo__54056_thumb.png"},
            {"title": "PBS US", "url": "/channels/PBS-US.html", "image": "/product_images/p/766/pbs_east__81153_thumb.jpg"},
            {"title": "RT America", "url": "/channels/RT-America.html", "image": "/product_images/l/726/Russia-today-logo__86701_thumb.png"},
            {"title": "Showtime US", "url": "/channels/Showtime-US.html", "image": "/product_images/t/233/showtime__67945_thumb.jpg"},
            {"title": "Spike", "url": "/channels/Spike.html", "image": "/product_images/z/232/Spike_logo_2015__98357_thumb.png"},
            {"title": "Sportsnet 1", "url": "/channels/Sportsnet-1.html", "image": "/product_images/x/985/Sportsnetone2011__31537_thumb.png"},
            {"title": "Sportsnet 360", "url": "/channels/Sportsnet-360.html", "image": "/product_images/a/095/Sportsnet-360-Logo__31086_thumb.jpg"},
            {"title": "Sportsnet World", "url": "/channels/Sportsnet-World.html", "image": "/product_images/e/626/SportsnetWorld__37094_thumb.png"},
            {"title": "Starz US", "url": "/channels/Starz%252dUS.html", "image": "/product_images/f/200/Starz_2008__56778_thumb.png"},
            {"title": "Syfy", "url": "/channels/Syfy.html", "image": "/product_images/f/954/syfy__52943_thumb.jpg"},
            {"title": "TBS East", "url": "/channels/TBS.East.html", "image": "/product_images/f/523/TBS.svg__23453_thumb.png"},
            {"title": "TLC US", "url": "/channels/TLC-US.html", "image": "/product_images/g/894/TLC_USA_logo__18952_thumb.png"},
            {"title": "TNT East", "url": "/channels/TNT-East.html", "image": "/product_images/e/600/tnt__28275_thumb.jpg"},
            {"title": "TSN 1", "url": "/channels/TSN%252d1.html", "image": "/product_images/u/487/tsn__98863_thumb.jpg"},
            {"title": "TSN 2", "url": "/channels/TSN%252d2.html", "image": "/product_images/b/342/tsn2__61112_thumb.jpg"},
            {"title": "TSN 3", "url": "/channels/TSN%252d3.html", "image": "/product_images/f/245/tsn3__97431_thumb.png"},
            {"title": "TSN 4", "url": "/channels/TSN%252d4.html", "image": "/product_images/y/045/tsn4__75023_thumb.png"},
            {"title": "USA Network", "url": "/channels/USA%252dNetwork.html", "image": "/product_images/a/517/usa_network__57030_thumb.jpg"},
            {"title": "VH1 US", "url": "/channels/VH1%252dUS.html", "image": "/product_images/l/556/VH1_logonew__62136_thumb.png"},
            {"title": "WeatherNation", "url": "/channels/WeatherNation.html", "image": "/product_images/h/491/WeatherNation_logo__53910_thumb.png"},
            {"title": "WGN 9 CW Chicago", "url": "/channels/WGN-9-CW-Chicago.html", "image": "/product_images/k/035/Wgncwlogo__34261_thumb.png"},
            {"title": "WJHL Tennessee", "url": "/channels/WJHL-Tennessee.html", "image": "/product_images/l/084/WJHL-TV_2012_logo__63534_thumb.png"},
            {"title": "WTHI Terre Haute", "url": "/channels/WTHI-Terre-Haute.html", "image": "/product_images/j/981/WTHI_2012_Logo__76059_thumb.png"},
            {"title": "WWE", "url": "/channels/WWE.html", "image": "/product_images/h/880/world_wrestling_entertainment__70123_thumb.jpg"}
        ]
        self.MUSIC_TV = [
            {"title": "BET East", "url": "/channels/BET-East.html", "image": "/product_images/e/316/BET_Logo__19751_thumb.png"},
            {"title": "BritAsia TV", "url": "/channels/BritAsia-TV.html", "image": "/product_images/a/374/brit_asia_tv__34173_thumb.jpg"},
            {"title": "Busuioc TV", "url": "/channels/Busuioc-TV.html", "image": "/product_images/y/696/busuioc-tv1__38947_thumb.png"},
            {"title": "Capital", "url": "/channels/Capital.html", "image": "/product_images/r/954/Capital_TV_logo__27138_thumb.png"},
            {"title": "Heart TV", "url": "/channels/Heart-TV.html", "image": "/product_images/z/606/Heart_TV_logo__58712_thumb.png"},
            {"title": "MTV Classic-UK", "url": "/channels/MTV%252dClassic%252dUK.html", "image": "/product_images/z/697/MTV_Classic_logo_2013__65812_thumb.png"},
            {"title": "MTV Dance", "url": "/channels/MTV%252dDance.html", "image": "/product_images/x/506/MTV_Dance_2013__40554_thumb.png"},
            {"title": "MTV Hits", "url": "/channels/MTV-Hits.html", "image": "/product_images/b/347/MTV_Hits_Logo_2012__61325_thumb.png"},
            {"title": "MTV Rocks", "url": "/channels/MTV%252dRocks.html", "image": "/product_images/w/993/MTV_Rocks_logo_2013__21136_thumb.png"},
            {"title": "MTV", "url": "/channels/MTV.html", "image": "/product_images/w/104/MTV_Logo_2010__92640_thumb.png"},
            {"title": "Noroc TV", "url": "/channels/Noroc-TV.html", "image": "/product_images/g/451/noroc_tv__33489_thumb.jpg"},
            {"title": "UTV", "url": "/channels/UTV.html", "image": "/product_images/c/088/u_tv__51904_thumb.jpg"},
            {"title": "VH1 EU", "url": "/channels/VH1-EU.html", "image": "/product_images/k/656/VH1_logonew__46519_thumb.png"},
            {"title": "VH1 US", "url": "/channels/VH1%252dUS.html", "image": "/product_images/l/556/VH1_logonew__62136_thumb.png"}
        ]
        self.NEWS_TV = [
            {"title": "RT America", "url": "/channels/RT-America.html", "image": "/product_images/l/726/Russia-today-logo__86701_thumb.png"},
            {"title": "Sky News Arab", "url": "/channels/Sky-News-Arab.html", "image": "/product_images/z/091/Sky_News_Arabia_logo__60552_thumb.png"},
            {"title": "Sky News", "url": "/channels/Sky-News.html", "image": "/product_images/j/542/sky_news__04995_thumb.jpg"},
            {"title": "Sky TG 24", "url": "/channels/Sky-TG-24.html", "image": "/product_images/u/637/SKY_TG24__09392_thumb.png"},
            {"title": "Tagesschau24", "url": "/channels/tagesschau24.html", "image": "/product_images/f/462/301px-Tagesschau24-2012__84641_thumb.png"},
            {"title": "WeatherNation", "url": "/channels/WeatherNation.html", "image": "/product_images/h/491/WeatherNation_logo__53910_thumb.png"},
            {"title": "WJHL Tennessee", "url": "/channels/WJHL-Tennessee.html", "image": "/product_images/l/084/WJHL-TV_2012_logo__63534_thumb.png"},
            {"title": "WTHI Terre Haute", "url": "/channels/WTHI-Terre-Haute.html", "image": "/product_images/j/981/WTHI_2012_Logo__76059_thumb.png"}
        ]
        self.SPORTS_TV = [
            {"title": "Astro SS 1", "url": "/channels/Astro-SS-1.html", "image": "/product_images/o/658/astro_supersport__73976_thumb.png"},
            {"title": "Astro SS 3", "url": "/channels/Astro-SS3.html", "image": "/product_images/y/587/Astro_SuperSport_3_logo__27574_thumb.png"},
            {"title": "Astro SS 4", "url": "/channels/Astro-SS-4.html", "image": "/product_images/i/619/gambar_astro_supersport_4__72673_thumb.JPG"},
            {"title": "Chelsea TV", "url": "/channels/Chelsea-TV.html", "image": "/product_images/s/436/chelsea_tv__40010_thumb.jpg"},
            {"title": "Cycling 1", "url": "/channels/Cycling-1.html", "image": "/product_images/w/262/c-ing__88722_thumb.jpg"},
            {"title": "Cycling 2", "url": "/channels/Cycling2.html", "image": "/product_images/d/125/c-ing__51846_thumb.jpg"},
            {"title": "ESPN2", "url": "/channels/ESPN2.html", "image": "/product_images/a/831/ESPN2_logo__59298_thumb.png"},
            {"title": "ESPN.1", "url": "/channels/ESPN.1.html", "image": "/product_images/y/742/ESPN__66232_thumb.png"},
            {"title": "Eurosport1 FR", "url": "/channels/Eurosport1-FR.html", "image": "/product_images/g/221/eurosport__72244_thumb.jpg"},
            {"title": "Eurosport", "url": "/channels/Eurosport.html", "image": "/product_images/r/279/eurosport__75580_thumb.jpg"},
            {"title": "Golf TV", "url": "/channels/Golf-TV.html", "image": "/product_images/s/418/golf_channel_us__36323_thumb.jpg"},
            {"title": "L-Equipe 21", "url": "/channels/L%252dEquipe%252d21.html", "image": "/product_images/k/157/l_equipe_21_fr__45356_thumb.jpg"},
            {"title": "Manchester United TV", "url": "/channels/Manchester-United-TV.html", "image": "/product_images/i/675/mutv__18782_thumb.jpg"},
            {"title": "MLB Network", "url": "/channels/MLB.Network.html", "image": "/product_images/o/660/mlb_network__27352_thumb.jpg"},
            {"title": "Motors TV", "url": "/channels/Motors-TV.html", "image": "/product_images/s/922/MotorsTV-logo__73046_thumb.png"},
            {"title": "NBA", "url": "/channels/NBA.html", "image": "/product_images/u/073/nba_tv__20518_thumb.jpg"},
            {"title": "NBC Sports", "url": "/channels/NBC.Sports.html", "image": "/product_images/q/063/nbc_sports_network__66246_thumb.jpg"},
            {"title": "NFL", "url": "/channels/NFL.html", "image": "/product_images/n/410/nfl_network__08611_thumb.jpg"},
            {"title": "NHL Network", "url": "/channels/NHL-Network.html", "image": "/product_images/v/462/NHL_Network_2011__53239_thumb.png"},
            {"title": "Pac 12 Arizona", "url": "/channels/Pac-12-Arizona.html", "image": "/product_images/f/860/Pac-12_Networks_logo__13866_thumb.png"},
            {"title": "Pac 12 Bay Area", "url": "/channels/Pac-12-Bay-Area.html", "image": "/product_images/c/453/Pac-12_Networks_logo__07345_thumb.png"},
            {"title": "Pac 12 Los Angeles", "url": "/channels/Pac.12-Los-Angeles.html", "image": "/product_images/y/660/Pac-12_Networks_logo__02467_thumb.png"},
            {"title": "Pac 12 Mountain", "url": "/channels/Pac-12-Mountain.html", "image": "/product_images/n/028/Pac-12_Networks_logo__03916_thumb.png"},
            {"title": "Pac 12 Network", "url": "/channels/Pac-12-Network.html", "image": "/product_images/f/759/Pac-12_Networks_logo__13527_thumb.png"},
            {"title": "Pac 12 Oregon", "url": "/channels/Pac-12-Oregon.html", "image": "/product_images/d/706/Pac-12_Networks_logo__50740_thumb.png"},
            {"title": "Pac 12 Washington", "url": "/channels/Pac-12-Washington.html", "image": "/product_images/d/574/Pac-12_Networks_logo__54056_thumb.png"},
            {"title": "Premier", "url": "/channels/Premier.html", "image": "/product_images/i/771/Premier_Sports_logo__59689_thumb.png"},
            {"title": "Racing UK", "url": "/channels/Racing-UK.html", "image": "/product_images/h/544/racing_uk__87840_thumb.jpg"},
            {"title": "Rai Sport", "url": "/channels/Rai-Sport.html", "image": "/product_images/x/320/1920px-Rai_Sport_-_Logo_2017__46337_thumb.png"},
            {"title": "Real Madrid TV", "url": "/channels/Real-Madrid-TV.html", "image": "/product_images/u/980/real_madrid_tv_es__39458_thumb.png"},
            {"title": "SCalcio", "url": "/channels/SCalcio.html", "image": "/product_images/a/134/sky_it_calcio__42011_thumb.png"},
            {"title": "Setanta", "url": "/channels/Setanta.html", "image": "/product_images/t/788/setanta_sports_ie__75006_thumb.jpg"},
            {"title": "Sky Sport 2", "url": "/channels/Sky%252dSport2.html", "image": "/product_images/f/498/sky_de_sport_02_hd__85038_thumb.jpg"},
            {"title": "Sky Sport Uno", "url": "/channels/Sky-Sport%252dUno.html", "image": "/product_images/z/059/sky_iit_sport1__99735_thumb.jpg"},
            {"title": "Sportsnet 1", "url": "/channels/Sportsnet-1.html", "image": "/product_images/x/985/Sportsnetone2011__31537_thumb.png"},
            {"title": "Sportsnet 360", "url": "/channels/Sportsnet-360.html", "image": "/product_images/a/095/Sportsnet-360-Logo__31086_thumb.jpg"},
            {"title": "Sportsnet World", "url": "/channels/Sportsnet-World.html", "image": "/product_images/e/626/SportsnetWorld__37094_thumb.png"},
            {"title": "SSport 1", "url": "/channels/SSport-1.html", "image": "/product_images/p/154/Sky_Sport_1_off-air_2011__91616_thumb.png"},
            {"title": "TSN-1", "url": "/channels/TSN%252d1.html", "image": "/product_images/u/487/tsn__98863_thumb.jpg"},
            {"title": "TSN-2", "url": "/channels/TSN%252d2.html", "image": "/product_images/b/342/tsn2__61112_thumb.jpg"},
            {"title": "TSN-3", "url": "/channels/TSN%252d3.html", "image": "/product_images/f/245/tsn3__97431_thumb.png"},
            {"title": "TSN-4", "url": "/channels/TSN%252d4.html", "image": "/product_images/y/045/tsn4__75023_thumb.png"},
            {"title": "WWE", "url": "/channels/WWE.html", "image": "/product_images/h/880/world_wrestling_entertainment__70123_thumb.jpg"}
        ]
        self.categories = [
            {'title': 'All Channels', 'url': 'all_channels', 'image': None},
            {'title': 'Random Channel', 'url': 'random_channel', 'image': None},
            {'title': 'MUSIC_TV', 'url': 'self.MUSIC_TV', 'image': None},
            {'title': 'NEWS_TV', 'url': 'self.NEWS_TV', 'image': None},
            {'title': 'SPORTS_TV', 'url': 'self.SPORTS_TV', 'image': None},
            {'title': 'USA_TV', 'url': 'self.USA_TV', 'image': None},
            {'title': 'UK_TV', 'url': 'self.UK_TV', 'image': None},
            {'title': 'SWISS_TV', 'url': 'self.SWISS_TV', 'image': None},
            {'title': 'NORDIC_TV', 'url': 'self.NORDIC_TV', 'image': None},
            {'title': 'ITALIAN_TV', 'url': 'self.ITALIAN_TV', 'image': None},
            {'title': 'GERMAN_TV', 'url': 'self.GERMAN_TV', 'image': None},
            {'title': 'FRENCH_TV', 'url': 'self.FRENCH_TV', 'image': None},
            {'title': 'ARAB_TV', 'url': 'self.ARAB_TV', 'image': None},
        ]


    def root(self):
        try:
            for i in self.categories:
                title = client.replaceHTMLCodes(i['title'])
                url = i['url']
                if i['image']:
                    image = self.base_link + i['image']
                else:
                    image = i['image']
                if i['url'] == 'random_channel':
                    action = 'shadownet_scrape_channel'
                else:
                    action = 'shadownet_scrape_category'
                self.list.append({'title': title, 'url': url, 'image': image, 'action': action})
            addDirectory(self.list)
            return self.list
        except:
            log_utils.log('root', 1)
            return self.list


    def scrape_category(self, url):
        try:
            if url == 'all_channels':
                self.channels += self.ARAB_TV
                self.channels += self.FRENCH_TV
                self.channels += self.GERMAN_TV
                self.channels += self.ITALIAN_TV
                self.channels += self.NORDIC_TV
                self.channels += self.SWISS_TV
                self.channels += self.UK_TV
                self.channels += self.USA_TV
                self.channels += self.MUSIC_TV
                self.channels += self.NEWS_TV
                self.channels += self.SPORTS_TV
            if url == 'self.ARAB_TV':
                self.channels = self.ARAB_TV
            if url == 'self.FRENCH_TV':
                self.channels = self.FRENCH_TV
            if url == 'self.GERMAN_TV':
                self.channels = self.GERMAN_TV
            if url == 'self.ITALIAN_TV':
                self.channels = self.ITALIAN_TV
            if url == 'self.NORDIC_TV':
                self.channels = self.NORDIC_TV
            if url == 'self.SWISS_TV':
                self.channels = self.SWISS_TV
            if url == 'self.UK_TV':
                self.channels = self.UK_TV
            if url == 'self.USA_TV':
                self.channels = self.USA_TV
            if url == 'self.MUSIC_TV':
                self.channels = self.MUSIC_TV
            if url == 'self.NEWS_TV':
                self.channels = self.NEWS_TV
            if url == 'self.SPORTS_TV':
                self.channels = self.SPORTS_TV
            for i in self.channels:
                title = client.replaceHTMLCodes(i['title'])
                link = self.base_link + i['url']
                image = self.base_link + i['image']
                self.list.append({'title': title, 'url': link, 'image': image, 'action': 'shadownet_scrape_channel'})
            self.list = sorted(self.list, key=lambda k: k['title'])
            addDirectory(self.list)
            return self.list
        except:
            log_utils.log('scrape_category', 1)
            return self.list


    def scrape_channel(self, url):
        try:
            if url == 'random_channel':
                choice = random.choice(self.USA_TV)
                url = self.base_link + choice['url']
            if not url.startswith('http'):
                url = self.base_link + url
            self.cookie = client.request(url, output='cookie', timeout='5')
            html = client.request(url, cookie=self.cookie)
            try:
                title = client.parseDOM(html, 'meta', attrs={'property': 'og:title'}, ret='content')[0]
            except:
                title = url.replace(self.base_link, '')
            title = client.replaceHTMLCodes(title)
            link = client.parseDOM(html, 'iframe', ret='src')[0]
            html2 = client.request(link, cookie=self.cookie)
            link2 = re.findall('{source: "(.+?)",', html2)[0]
            item = control.item(path=link2)
            item.setInfo(type='Video', infoLabels={'title': title})
            item.setProperty('IsPlayable', 'true')
            return control.player.play(link2, item)
        except:
            log_utils.log('scrape_channel', 1)
            control.infoDialog('Error : No Stream Available.', sound=False, icon='INFO')
            return


def addDirectory(items, queue=False, isFolder=True):
    if items == None or len(items) == 0:
        control.idle()
    sysaddon = sys.argv[0]
    syshandle = int(sys.argv[1])
    addonFanart = control.addonFanart()
    for i in items:
        try:
            url = '%s?action=%s&url=%s' % (sysaddon, i['action'], i['url'])
            title = i['title']
            thumb = i['image'] or 'DefaultVideo.png'
            item = control.item(label=title)
            item.setProperty('IsPlayable', 'true')
            item.setArt({'icon': thumb, 'thumb': thumb, 'fanart': addonFanart})
            control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
        except Exception:
            log_utils.log('addDirectory', 1)
            pass
    control.content(syshandle, 'addons')
    control.directory(syshandle, cacheToDisc=True)


