# -*- coding: utf-8 -*-

import sys
from resources.lib.modules import control
from resources.lib.modules import log_utils


def playItem(url):
    try:
        item = control.item(path=url)
        item.setProperty('IsPlayable', 'true')
        control.player.play(url, item)
    except:
        log_utils.log('playItem', 1)
        control.infoDialog('Error : No Stream Available.', sound=False, icon='INFO')
        return


def playMedia(url):
    try:
        control.execute('PlayMedia(%s)' % url)
    except:
        log_utils.log('playMedia', 1)
        control.infoDialog('Error : No Stream Available.', sound=False, icon='INFO')
        return


