
channels = [


    {"title": "Don`t Tell The Bride UK", "url": "https://lds-donttellbride-simplestream.amagi.tv/hls/amagi_hls_data_ldsAAAAAA-donttellthebride-simplestream/CDN/master.m3u8", "image": "https://i.imgur.com/1h9abQi.jpg"},
    {"title": "Real Crime", "url": "https://lds-realcrime-simplestream.amagi.tv/hls/amagi_hls_data_ldsAAAAAA-realcrime-simplestream/CDN/master.m3u8", "image": "https://i.imgur.com/kwdX93h.jpg"},
    {"title": "Real Life", "url": "https://lds-realfamilies-simplestream.amagi.tv/hls/amagi_hls_data_ldsAAAAAA-real-families-simplestream/CDN/master.m3u8", "image": "https://i.imgur.com/A4gwz6d.jpg"},
    {"title": "Real Stories", "url": "https://lds-realstories-simplestream.amagi.tv/hls/amagi_hls_data_ldsAAAAAA-realstoriessimplestream/CDN/master.m3u8", "image": "https://i.imgur.com/77OXe64.jpg"},
    {"title": "Real Wild", "url": "https://lds-realwild-simplestream.amagi.tv/hls/amagi_hls_data_ldsAAAAAA-realwild-simplestream/CDN/master.m3u8", "image": "https://i.imgur.com/GcloVnf.jpg"},
    {"title": "Timeline", "url": "https://lds-timeline-simplestream.amagi.tv/hls/amagi_hls_data_ldsAAAAAA-timelinesimplestream/CDN/master.m3u8", "image": "https://i.imgur.com/1rrVdP4.jpg"},
    {"title": "Wonder", "url": "https://lds-wonder-simplestream.amagi.tv/hls/amagi_hls_data_ldsAAAAAA-wondorsimplestream/CDN/master.m3u8", "image": "https://i.imgur.com/0JgIMYA.jpg"},


]


